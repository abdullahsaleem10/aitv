package com.dooo.android;

import android.os.Bundle;

import com.dooo.android.utils.BaseActivity;

public class PaytmPaymentGatway extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paytm_payment_gatway);

    }
}